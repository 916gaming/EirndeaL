
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import MonopolyDeal from './MonopolyDeal';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<MonopolyDeal />);
